import { AfterViewInit, Component, ElementRef, ViewChild } from '@angular/core';
import * as L from 'leaflet';

@Component({
  selector: 'app-mapa',
  standalone: true,
  template: `
    <div class="map-container">
      <div class="map-frame">
        <div #mapa id="map"></div>
      </div>
    </div>
  `,
  styles: [
    `.map-container { height: 400px; width: 100%; }`,
    `#map { height: 100%; width: 100%; }`
  ]
})

export class MapaComponent implements AfterViewInit {
  private map: L.Map;

  private initMap(): void{
    this.map = L.map('mapid', {
      center: [36.7197137979015, -4.421553542327948],
      zoom: 20
    });
  }



  ngAfterViewInit(): void {
    this.initMap();
  }
}