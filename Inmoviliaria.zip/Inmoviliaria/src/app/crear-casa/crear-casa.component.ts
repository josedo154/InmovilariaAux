import { Component } from '@angular/core';

@Component({
  selector: 'app-crear-casa',
  imports: [],
  template: `
    <div>
      <form>
        <div>
          <label for="nombre">Name: </label>
          <input type="text" id="nombre" required>
        </div>

        <div>
          <label for="ciudad">City: </label>
          <input type="text" id="ciudad" required>
        </div>

        <div>
          <label for="estado">State: </label>
          <input type="text" id="estado" required>
        </div>

        <div>
          <label for="foto">Photo: </label>
          <input type="url" id="foto">
        </div>

        <div>
          <label for="unit">availableUnits: </label>
          <input type="number" id="unit" required>
        </div>

        <div>
          <label for="wifi">Wifi: </label>
          <input type="checkbox" id="wifi">
        </div>

        <div>
          <label for="laundry">Laundry: </label>
          <input type="checkbox" id="laundry">
        </div>

        <div>
          <label>Security: </label>
          <div>
            <input type="checkbox" value="alarma"> Alarma
            <input type="checkbox" value="camara"> Camara
            <input type="checkbox" value="puertaReforzada"> Puerta Reforzada
            <input type="checkbox" value="detectorHumo"> Detector de humos
          </div>
        </div>

        <input type="submit" value="Crear">
      </form>
    </div>
  `,
  standalone: true,
  styles: ``
})
export class CrearCasaComponent {

}
