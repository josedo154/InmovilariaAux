import {AfterViewInit, Component, ElementRef, Input, ViewChild, OnChanges, SimpleChanges} from '@angular/core';
import * as L from 'leaflet';

@Component({
  selector: 'app-mapa',
  standalone: true,
  template: `
    <div #mapa class="mapa border rounded shadow-sm p-2"></div>
  `,
  styles: [
    `.mapa {
      width: 100%;
      height: 400px;
    }`
  ]
})

export class MapaComponent implements AfterViewInit, OnChanges {
  @ViewChild('mapa', { static: false }) mapaContainer!: ElementRef;
  private map!: L.Map;
  private marker!: L.Marker;

  @Input() cordX: number = 0;
  @Input() cordY: number = 0;

  ngAfterViewInit(): void {
    this.map = L.map(this.mapaContainer.nativeElement).setView([this.cordX, this.cordY], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    }).addTo(this.map);

    this.marker = L.marker([this.cordX, this.cordY]).addTo(this.map)
        .bindPopup(`Ubicación: ${this.cordX}, ${this.cordY}`)
        .openPopup();
  }

  /*Changes: Objeto para manejar cambios en los inputs, sino se carga 0,0*/

  ngOnChanges(changes: SimpleChanges): void {
    if (this.map && changes['cordX'] || changes['cordY']) {
      this.map.setView([this.cordX, this.cordY], 13);
      this.marker.setLatLng([this.cordX, this.cordY])
          .bindPopup(`Ubicación: ${this.cordX}, ${this.cordY}`)
          .openPopup();
    }
  }
}
